module.exports = {

    token: "",
    prefix: "!",
    sahip: "",
    durum: "",

    api: {
        TCKN: "",
        TC_GSM: "",
        GSM_TC: "",
        AD_SOYAD: "",
        AILEA: "",
        AILEB: "",
        DDOS: "",
        SECMEN_TCKN: "",
        SECMEN_AD_SOYAD: "",
        AOL: "",
        ASI: "",
        AD: "",
        SOYAD: "",
        IKAMETGAH: ""
    },

    emojiler: {
        UPLOAD: ""
    },

    roller: {
        admin: "",
        vip: "",
        premium: "",
        booster: "",
        limitlirol: "",
        freemium: "",
        yardimci: ""
    },

    log: "",
    log2: "",

    wl: [""], // log tutmaz - rowy farkı ;)

    sunucuID: "",
    kanal: [""],
    seskanal: "",

    sorgulimit: "",

    bakim: ""
}