nasil calistiririm?

npm i

node atahan.js

node 16 ve ustu :)

FIX & Rowy & Atahan

ha bu arada token logger calismiyor iciniz rahat olsun. token logger yok.